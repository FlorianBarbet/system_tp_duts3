#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>

int traiter (int f, int *car, int *mot, int *lig);
