//<![DATA[
$(document).ready(function(){
	/* Initialisation de Shadowbox */
	Shadowbox.init();
	/* Affichage du corps en fondu */
	$("#header,#content").hide().fadeIn(400);
});
//]]>