function affiche(){

	$('#accueil').click(function() {
		document.getElementById('acc').className='visibl';
		document.getElementById('obj').className='cache';
		document.getElementById('moy').className='cache';
		document.getElementById('eta').className='cache';
		document.getElementById('eve').className='cache';
		document.getElementById('bil').className='cache';
	});

	$('#objectifs').click(function() {
		document.getElementById('acc').className='cache';
		document.getElementById('obj').className='visibl';
		document.getElementById('moy').className='cache';
		document.getElementById('eta').className='cache';
		document.getElementById('eve').className='cache';
		document.getElementById('bil').className='cache';
	});

	$('#moyens').click(function() {
		document.getElementById('acc').className='cache';
		document.getElementById('obj').className='cache';
		document.getElementById('moy').className='visibl';
		document.getElementById('eta').className='cache';
		document.getElementById('eve').className='cache';
		document.getElementById('bil').className='cache';
	});

	$('#etablissements').click(function() {
		document.getElementById('acc').className='cache';
		document.getElementById('obj').className='cache';
		document.getElementById('moy').className='cache';
		document.getElementById('eta').className='visibl';
		document.getElementById('eve').className='cache';
		document.getElementById('bil').className='cache';
	});

	$('#evenements').click(function() {
		document.getElementById('acc').className='cache';
		document.getElementById('obj').className='cache';
		document.getElementById('moy').className='cache';
		document.getElementById('eta').className='cache';
		document.getElementById('eve').className='visibl';
		document.getElementById('bil').className='cache';
	});

	$('#bilan').click(function() {
		document.getElementById('acc').className='cache';
		document.getElementById('obj').className='cache';
		document.getElementById('moy').className='cache';
		document.getElementById('eta').className='cache';
		document.getElementById('eve').className='cache';
		document.getElementById('bil').className='visibl';
	});

}
