//FLORIAN BARBET SAULE 14

int obtenir_valeur_aleatoire(int borne_superieure);

void lancer_patate(int out, int valeur);

int recevoir_patate(int in);

void demarrer_recepteur_patate(int in, int out);

